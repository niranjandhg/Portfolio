const express = require('express');
const app = express();
const port = 8083;

// Serve static assets from the public folder
app.use(express.static('public'));

// Set up EJS as the view engine
app.set('view engine', 'ejs');

// Routes
const homeRouter = require('./routes/home');
const aboutRouter = require('./routes/about');
const projectsRouter = require('./routes/projects');
const servicesRouter = require('./routes/services');
const contactRouter = require('./routes/contact');

const projectsRouter = require('./routes/projects');
// Include other route files as needed

// Use the routers in your app
app.use('/projects', projectsRouter);
// Use other routers as needed

app.use('/', homeRouter);
app.use('/about', aboutRouter);
app.use('/projects', projectsRouter);
app.use('/services', servicesRouter);
app.use('/contact', contactRouter);

// ...

// Parse JSON and URL-encoded form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// POST route for handling form submissions
app.post('/send-message', (req, res) => {
  const { firstName, lastName, email, message } = req.body;

  // You can add code here to process the submitted message, send emails, etc.

  res.send('Message sent successfully'); // Send a confirmation message to the user
});

// ...


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
