// routes/about.js
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('about'); // Render the about EJS template
});

module.exports = router;
