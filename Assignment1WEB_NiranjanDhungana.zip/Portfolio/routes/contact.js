// routes/contact.js
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('contact'); // Render the contact EJS template
});

// Handle form submission (POST request)
router.post('/', (req, res) => {
  // Process form data and send email (if needed)
  const { firstName, lastName, contactNumber, email, message } = req.body;

  //

  // Redirect back to the home page or display a thank you message
  res.render('thankyou', { firstName }); // Render a thank you EJS template
});

module.exports = router;
