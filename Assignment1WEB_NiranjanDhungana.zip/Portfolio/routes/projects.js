const express = require('express');
const router = express.Router();

// Sample project data (replace with your own data)
const projectsData = [
  {
    title: 'E-Commerce Website Redesign',
    description: 'For this project, I led a team in revamping an existing e-commerce website for a client in the fashion industry...',
    // Add other project details here
  },
  {
    title: 'Mobile App Development for Health and Wellness',
    description: 'I developed a mobile application designed to promote health and wellness...',
    // Add other project details here
  },
  {
    title: 'Data Analytics Dashboard for Financial Analysis',
    description: 'In collaboration with a financial services firm, I created a data analytics dashboard that allowed analysts to visualize and analyze financial data in real-time...',
    // Add other project details here
  },
];

// Route to display the projects list page
router.get('/', (req, res) => {
  res.render('project', { projectsData });
});

module.exports = router;
