const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('services', {
    services: [
      {
        title: 'Web Development',
        description: 'We create responsive and user-friendly websites tailored to your needs.',
      },
      {
        title: 'Mobile App Development',
        description: 'We develop native and cross-platform mobile applications for iOS and Android.',
      },
      {
        title: 'Graphic Design',
        description: 'Our creative designers can produce stunning graphics for your branding and marketing needs.',
      },
      // Add more services as needed
    ],
  });
});

module.exports = router;
